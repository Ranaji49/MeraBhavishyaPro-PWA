Mera Bhavishya Pro – Gold Edition (PWA)

Included files:
- index.html
- manifest.json
- service-worker.js
- offline.html
- icons/* (72-512)

How to test locally:
1. cd into this folder
2. python3 -m http.server 8000
3. open http://localhost:8000/index.html

How to deploy to Vercel:
1. Go to https://vercel.com and login
2. Click 'New Project' -> choose 'Upload' or 'Deploy from Local Files'
3. Select this folder and deploy (Framework: None)

After deploy, open the site on mobile and 'Add to Home Screen' to install.

Mera Bhavishya Pro — Full Static App (Demo)

Included:
- index.html (home)
- horoscope.html
- kundli.html (mock)
- matchmaking.html (mock)
- tarot.html
- numerology.html
- ai-chat.html (local bot)
- manifest.json, service-worker.js, offline.html
- assets/style.css and icons/

Notes:
- This is a static demo. Kundli and horoscope are mock/deterministic, not real astrology.
- To make it production-grade, integrate a real astrology API (e.g., Prokerala) and optionally an OpenAI backend for AI chat.
- To deploy: upload this folder to GitHub repo root (already done) and deploy to Vercel or GitHub Pages.

How to test locally:
1. cd into folder
2. python3 -m http.server 8000
3. open http://localhost:8000 in browser
